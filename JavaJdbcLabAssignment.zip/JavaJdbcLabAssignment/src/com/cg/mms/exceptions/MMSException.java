package com.cg.mms.exceptions;

import org.apache.log4j.Logger;

public class MMSException extends Exception{
	static Logger logger=Logger.getLogger(MMSException.class);
	
	public MMSException(String message) {
		super(message);
		logger.error("exception class has been called");
		
		
	}

}
