package com.cg.mms.presentation;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.mms.exceptions.MMSException;
import com.cg.mms.service.MobileService;
import com.cg.mms.service.MobileServiceImpl;

public class DeleteMobileId {

	static Logger logger=Logger.getLogger(DeleteMobileId.class);
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter mobile id for the deletion");
		Integer id=scanner.nextInt();
		logger.info("mobile Id entered for deletion");
		
		MobileService service =new MobileServiceImpl();
		int result;
		try {
			result = service.DeleteMobileRow(id);
			logger.info("service layer called");
			System.out.println(result+" Deleted");
			logger.info("1 row deleted");
		} catch (MMSException e) {
			System.out.println(e.getMessage());
			logger.error("deletion has been not performed");
		}
		//scanner.close();
		
		

	}

}
