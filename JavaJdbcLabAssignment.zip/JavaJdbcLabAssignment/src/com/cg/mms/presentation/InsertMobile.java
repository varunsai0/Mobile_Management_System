package com.cg.mms.presentation;


import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.mms.exceptions.MMSException;
import com.cg.mms.model.Mobiles;
import com.cg.mms.service.MobileService;
import com.cg.mms.service.MobileServiceImpl;

public class InsertMobile {

	static Logger logger=Logger.getLogger(InsertMobile.class);
	
	public static void main(String[] args) {
		
		
	
		logger.info("inside the insert mobile method");
		MobileService service=new MobileServiceImpl();
	  Scanner scanner=new Scanner(System.in);
	 
	  System.out.println("Enter mobile id");
	  Integer id=scanner.nextInt();
	  logger.info("mobile id entered as"+id);
	  scanner.nextLine();
		System.out.println("Enter name of the mobile");
		String name=scanner.nextLine();
		logger.info("Name of the mobile is"+name);
		System.out.println("Enter price of the mobile");
		Double price=scanner.nextDouble();
		logger.info("price of the mobile is:"+price);
		System.out.println("Enter quantity");
		Integer quantity=scanner.nextInt();
		logger.info("quantity enter is:"+quantity);
		if(quantity<=0)
		{
			System.out.println("Quantity should be greater than zero");
			logger.info("quantity not greater");
			
		}else
		{
		
		Mobiles mobiles=new Mobiles();
		mobiles.setMobileId(id);
		mobiles.setName(name);
		mobiles.setPrice(price);
		mobiles.setQuantity(quantity);
		
		try {
			int result=service.insertMobileData(mobiles);
			System.out.println(result+"inserted");
			logger.info("1 row inserted");
		} catch (MMSException e) {
			System.out.println(e.getMessage());
			logger.error("data has been not inserted");
		}
		
		
		}
		//scanner.close();
		
		
		
		
//		try {
//			service.createTable();
//		} catch (MMSException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

}
