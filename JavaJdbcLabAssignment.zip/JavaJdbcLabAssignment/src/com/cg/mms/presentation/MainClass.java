package com.cg.mms.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;

public class MainClass {
	static Logger logger=Logger.getLogger(MainClass.class);

	public static void main(String[] args) {
	//	PropertyConfigurator.configure("resources/log4j.properties");
		
		//static Logger logger=Logger.getLogger(MainClass.class);
		int choice=0;
		Scanner scanner = null;
	//	boolean flag=false;
	

		do {
		
		System.out.println("******Mobile Management System*******");
           logger.info("mobile management started:");
		System.out.println("1.Insert mobile details");
		System.out.println("2.Add purchase details");
		System.out.println("3.View all mobiles");
		System.out.println("4.Delete mobile based on mobile Id");
		System.out.println("5.Search mobiles based on price range");
		System.out.println("0.Exit");
		logger.info("Options have been displayed");
		scanner = new Scanner(System.in);
            
		System.out.println("Enter  your choice");
		try {
		choice = scanner.nextInt();
            
		switch (choice) {
		case 1:
				InsertMobile.main(null);

			break;
		case 2:
			   UpdatePurchaseDetails.main(null);

			break;
		case 3:
			   SelectAllMobiles.main(null);

			break;
		case 4:
			  DeleteMobileId.main(null);

			break;
		case 5:
			    MobileBetweenRange.main(null);

			break;
		case 0:
			     System.out.println("You are exited from the mobile management system");
			     
			break;
		default:
			System.out.println("You have entered wrong input");
			System.out.println("please select valid choice");
			break;
		}
           
             
		}catch(InputMismatchException e)
		{
			System.out.println("please enter only given choice i.e digits");
			choice=10;
		}
     
		}while(choice!=0);
	
	
	scanner.close();

	}

}
