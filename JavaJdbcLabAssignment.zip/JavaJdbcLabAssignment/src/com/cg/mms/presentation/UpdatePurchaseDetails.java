package com.cg.mms.presentation;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.mms.exceptions.MMSException;
import com.cg.mms.model.PurchaseDetails;
import com.cg.mms.service.MobileService;
import com.cg.mms.service.MobileServiceImpl;

public class UpdatePurchaseDetails {

	static Logger logger=Logger.getLogger(UpdatePurchaseDetails.class);
	public static void main(String[] args) {
		
		
		Scanner scanner=new Scanner(System.in);
		
		
		System.out.println("Enter customer name:");
		String cName=scanner.nextLine();
		logger.info("customer name inserted");
		
		System.out.println("Enter mail id:");
		String mailId=scanner.nextLine();
		logger.info("mail id entered ");
		
		System.out.println("Enter phone number:");
		Long phoneNumber=scanner.nextLong();
		logger.info("phone number has been entered");
       System.out.println("Enter mobile id:");
       Integer mobileId=scanner.nextInt();
       logger.info("mobile id as been entered");
       
       PurchaseDetails details=new PurchaseDetails();
       details.setcName(cName);
       details.setMailId(mailId);
       details.setMobile_id(mobileId);
       details.setPhoneNumber(phoneNumber);
       logger.info("purchase details object as been created and details have been added");
       
       MobileService service=new MobileServiceImpl();
       boolean validateFlag=service.validateFields(details);
       logger.info("validations as been completed");
       System.out.println(validateFlag);
       
       if(validateFlag) {
    	   
    	   try {
			int Quantity= service.updateMobileQuantity(details);
			System.out.println(Quantity+"inserted");
		} catch (MMSException e) {
			System.out.println(e.getMessage());
			logger.error("exception has been handled");
		}
    	   
       }
       //scanner.close();
    	   
       
       
      
       
	}

}
